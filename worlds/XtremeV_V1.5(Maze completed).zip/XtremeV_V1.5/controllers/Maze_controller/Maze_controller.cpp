// XtremeV_controller
#include <webots/Robot.hpp>
#include <webots/DistanceSensor.hpp>
#include <webots/Motor.hpp>
#include <webots/Camera.hpp>
#include <webots/Display.hpp>
#include <webots/ImageRef.hpp>
#include <string>
#include <vector>
#include <webots/PositionSensor.hpp>    
#include "MainHeader.h"
#include "motion.cpp"
#include <algorithm>
//constants
#define TIME_STEP 32
#define NORMAL_SPEED 5
#define MAX_SPEED 7
#define IR_THRESHOLD 250
//macros
#define print(x)     cout << #x": " << x << "\n";
float kp1=0.02;
float kp2=0.06;
int A=1;
int d=220;
// All the webots classes are defined in the "webots" namespace
using namespace webots;
using namespace std;

//names
char motorNames[2][15] = { "left_motor", "right_motor" };
char dsNames[5][12] = { "left_ds", "right_ds","front_ds","left_ds(1)", "right_ds(1)"};
char irNames[8][4] = { "ir0", "ir1", "ir2", "ir3", "ir4", "ir5", "ir6", "ir7"};
char linearNames[3][15] = { "left_linear", "right_linear","ROD_Linear"  };
char servoName[15] = "Gripper_folder";
char psNames[2][15] = { "left_encoder", "right_encoder" };

Motor *motors[2];
Motor *linear[3];
Motor *servo;
DistanceSensor* dSensors[5];
DistanceSensor* irPanel[8];
PositionSensor *pSensors[2];
Robot *robot = new Robot();
Gyro* gyro;
//function init
void forward(int distance);
int Wall_Follower(DistanceSensor** dSensors);
void stop();
bool is_wall(char x);
void unit(DistanceSensor** dSensors);
int One_Wall_Follow(DistanceSensor** dSensors,char Dir);
int No_Wall_Follow(DistanceSensor** dSensors);

int main(int argc, char **argv) {

  
  // init Motors
  for (int i = 0; i < 2; i++)
  {
    motors[i] = robot->getMotor(motorNames[i]);
    motors[i]->setPosition(INFINITY);
    motors[i]->setVelocity(0.0);
  }
  
  //Hand Motors
  for (int i = 0; i < 3; i++)
  {
    linear[i] = robot->getMotor(linearNames[i]);
    linear[i]->setPosition(0.0);
  }
  
  servo =  robot->getMotor(servoName);
  servo->setPosition(0.0);
  
  // init Distance Sensors
  for (int i = 0; i < 5; i++)
  {
    dSensors[i] = robot->getDistanceSensor(dsNames[i]);
    dSensors[i]->enable(TIME_STEP);
  }
  
   // init IR Panel
  for (int i = 0; i < 8; i++)
  {
    irPanel[i] = robot->getDistanceSensor(irNames[i]);
    irPanel[i]->enable(TIME_STEP);
  }

  for (int i = 0; i < 2; i++)
  {
    pSensors[i] = robot->getPositionSensor(psNames[i]);
    pSensors[i]->enable(TIME_STEP);
  }
  
  gyro = robot->getGyro("gyro");
  gyro->enable(TIME_STEP);

  //variables
  // double ir_val;  // used for printing IR values
  string IR_Values;


  while (robot->step(TIME_STEP) != -1)
  {
    unit(dSensors);
  };

  delete robot;
  return 0;
}




void stop()
{
  for(int k=0;k<2;k++)
  {
    motors[k]->setVelocity(0);
  }
}

bool is_wall(char x)
{
  if (x=='l')
  {
    if (dSensors[0]->getValue()<2000)
    {
      return true;
    }
    return false;
  }
  else if (x=='f')
  {
    if (dSensors[2]->getValue()<2000)
    {
      return true;
    }
    return false;
  }
  else
  {
    if (dSensors[1]->getValue()<2000)
    {
      return true;
    }
    return false;
  }
}

void turning(double angle){
  std::cout << dSensors[0]->getValue() << " , " << dSensors[1]->getValue() << " , " << dSensors[2]->getValue() << std::endl;
  std::cout << "Position1: " << pSensors[0]->getValue() << " , " << pSensors[1]->getValue() << std::endl;
  motion::init_turn(motors, angle);
	while(robot->step(TIME_STEP) != -1){
		if (motion::turn_flag){
			motion::turn(motors, gyro);
		}
		else{
			break;
		}
	}

  if (std::abs(angle) == 90 * 3.14/180){
    //forward(50);
    std::cout << "Position: " << pSensors[0]->getValue() << " , " << pSensors[1]->getValue() << std::endl;
  }

  std::cout << "turning complete" << std::endl;
  forward(100);
}

void unit(DistanceSensor** dSensors)
{
  double distances[5];
  for(int j=0;j<5;j++)
  {
    distances[j]=dSensors[j]->getValue();
  }
  if (A) 
  { 
    if ((distances[1]<2500 and distances[0]<2500 and A==1) or A==2)
    {
    cout<<A<<endl;
    A=Wall_Follower(dSensors);
    }
    else if ((distances[0]<2500 and distances[1]>2500 and A==1) or A==4)
    {
      cout<<A<<endl;
      A=One_Wall_Follow(dSensors,'l');
    }
    else if ((distances[1]<2500 and distances[0]>2500 and A==1) or A==3)
    {
      cout<<A<<endl;
      A=One_Wall_Follow(dSensors,'r');
    }
    else
    {
      cout<<A<<endl;
      A=No_Wall_Follow(dSensors);
    }
  }
  else
  {
    //forward(370);
    if (!(is_wall('l')))
    {
      cout<<"turn90"<<endl;
      turning(90 * 3.14/180);
      
    }
    else if (!(is_wall('f')))
    {
      
    }
    else if (!(is_wall('r')))
    {
      cout<<"turn90r"<<endl;
      turning(-90 * 3.14/180);
      
    } 
    else
    {
      cout<<"turn180"<<endl;
      turning(180 * 3.14/180);
      
    } 
    A=1;
  }
}

void forward(int distance)
{
  double lambda = distance/35;
  double ang=pSensors[0] -> getValue();
  double ang1=ang;
  cout<<ang1<<endl;
  while (robot->step(TIME_STEP) != -1)
  {
    //cout<<ang1<<endl;
    ang1=pSensors[0] -> getValue();
    cout<<ang1<<endl;
    if (ang1-ang>lambda)////-//////////////////////[12.5 change kranw]
    {
      for(int k=0;k<2;k++)
      {
        motors[k]->setVelocity(0);
      }
      return;
    }
      for(int k=0;k<2;k++)
      {
        motors[k]->setVelocity(MAX_SPEED);
      }
  }
}

int Wall_Follower(DistanceSensor** dSensors)
{
  double distances[5];
  for(int j=0;j<5;j++)
  {
    distances[j]=dSensors[j]->getValue();
  }
  double center_err=distances[0]-900;
  double align_err=distances[1]-distances[4];
  float velocity_err=kp1*center_err;
  float Left_V=NORMAL_SPEED-velocity_err;
  float Right_V=NORMAL_SPEED+velocity_err;
  
  motors[0]->setVelocity(std::max(std::min(float(MAX_SPEED),Left_V),float(-MAX_SPEED)));
  motors[1]->setVelocity(std::max(std::min(float(MAX_SPEED),Right_V),float(-MAX_SPEED)));
  //std::cout << center_err<<endl;//std::max(std::min(float(MAX_SPEED),Left_V),float(-MAX_SPEED))<<"  "<< std::max(std::min(float(MAX_SPEED),Right_V),float(-MAX_SPEED)) <<endl;
  if (distances[1]>2500 or distances[0]>2500 or distances[2]<1500)
  {
  if (distances[2]<3000)
  {
    turning(180 * 3.14/180);
    return 1;
  }
    forward(d);
    std::cout << distances[0]<< " 2Wall "<<distances[1]<<endl;
    return 0;
  }
  return 2;
}

int One_Wall_Follow(DistanceSensor** dSensors,char Dir)
{
  int i=0;
  int mark=1;  
  double distances[5];
  for(int j=0;j<5;j++)
  {
    distances[j]=dSensors[j]->getValue();
  }
  if (Dir=='l')
  {
    i=1;
    mark=-1;
  }
  double align_err=distances[1-i]-distances[4-i];
  float velocity_err=kp2*align_err;
  float Left_V=NORMAL_SPEED+mark*velocity_err;
  float Right_V=NORMAL_SPEED-mark*velocity_err;
    
  motors[0]->setVelocity(std::max(std::min(float(MAX_SPEED),Left_V),float(-MAX_SPEED)));
  motors[1]->setVelocity(std::max(std::min(float(MAX_SPEED),Right_V),float(-MAX_SPEED)));
  if (distances[i]<2500)
  {
    //std::cout << " exit "<<endl;
    forward(d);
    std::cout << distances[0]<< " 1Wall "<<distances[1]<<endl;
    return 0;
  }
  return 3+i;
}

int No_Wall_Follow(DistanceSensor** dSensors)
{
  double distances[5];
  for(int j=0;j<5;j++)
  {
    distances[j]=dSensors[j]->getValue();
  }
  motors[0]->setVelocity(MAX_SPEED);
  motors[1]->setVelocity(MAX_SPEED);
  if (distances[0]<2500 or distances[1]<2500)
  {
    //std::cout << " exit "<<endl;
    forward(d);
    std::cout << distances[0]<< " 0Wall "<<distances[1]<<endl;
    return 0;
  }
  return 5;
}

// double align_err=distances[1]-distances[4];
    // float velocity_err=kp2*align_err;
    // float Left_V=NORMAL_SPEED-velocity_err;
    // float Right_V=NORMAL_SPEED+velocity_err;
    
    // motors[0]->setVelocity(std::max(std::min(float(MAX_SPEED),Left_V),float(-MAX_SPEED)));
    // motors[1]->setVelocity(std::max(std::min(float(MAX_SPEED),Right_V),float(-MAX_SPEED)));